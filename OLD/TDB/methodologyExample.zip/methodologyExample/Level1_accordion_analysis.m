% Analysis script -- Level 1 -- accordion analysis

clear all;

addpath('./Scripts'); % This directory contains auxiliary functions, e.g. STFT function.

% Reading the wavefiles
x = wavread('Level1_accordion.wav');
%-----------------------------
% Defining analysis parameters common to all sub-bands:

% Sampling rate (Section 3.1):
Fs = 44100;

% Initial number of sub-bands (Section 6):
N = 4;

% Defining hop (defines sampling rate of the parameters of the track):
min_Fs = Fs./(2.^(N-1)); % sampling frequency of last sub-band
hop = 2e-3; % hop sizes (Section 4.1)

% The following parameter defines the maximum number of consecutive missing
% data in a given track (Section 4.1):
max_inactive_time = 4;
%-----------------------------

% Dividing the signal into N sub-bands (Section 5.1):
xm = lp(x,N); % this function uses a laplacian pyramid to decompose the signal x in N sub-bands.

%-------------------------------------------------------------------------
% Preliminary analysis -- uncomment to plot the spectrum of the last
% sub-band.
%
%
% Checking silences and number of sub-bands needed.
% winLen = 40e-3;
% fLen = round(winLen*Fs);
% if(~mod(fLen,2)),
%     fLen=fLen+1;s
% end
% window = hann(fLen); % window
% dftLen = 2.^nextpow2(fLen);
% [S,t,f,X] = spec(x,Fs,hop,window,dftLen);
% 
% imagesc(t(1,:),f(:,1),20*log10(abs(S)));
% axis xy;
% return

%-------------------------------------------------------------------------
% 4th sub-band analysis

% signal:
x1 = xm{end};

% Sub-band Fs:
Fs1 = Fs./(2.^(N-1));

% Analysis parameters for this sub-band:

winLen = 40e-3; % window length in seconds.
% adjusting window length
% odd length only!
fLen = round(winLen*Fs1);
if(~mod(fLen,2)),
    fLen=fLen+1;
end

window = hann(fLen); % hanning window (Section 5.2)

% Zero-padding factor:
maxError = maxFreqError(4,N); % Function that returns the maximum tolerable error (in Hz) given the sub-band (Section 4.2.1).
ZP = zpfmin('hann',winLen,maxError); % Function that returns the zero-padding factor given the maximum error and the analysis window (Section 5.4). 

% Defining DFT length (Sections 5.2 and 5.4):
dftLen = 2^nextpow2(ZP*length(window));

% Partial tracking parameters (Section 5.6):
dF = 0.01;
kappa = 0.01;
min_track_length = (100e-3);

% Analysis:

% stft (Section 5.2)
[S,t,f,X] = spec(x1,Fs1,hop,window,dftLen); % This function estimates the spectrum.
% S -- the spectrum (matrix)
% t -- frame time index in seconds
% f -- frequency bin index in Hz
% X -- S = fft(X)

% obtaining noise floor estimate (Section 5.3):
nF = sse(abs(S),31); % Stochastic spectrum estimation method using a filter with 31 taps.

% Noise floor profile estimate (based on silence segment) (Section 5.3):
aNF = nF(:,1:ceil(0.126/hop));
aNF = 3*mean(aNF,2); % global threshold is 3 times the estimated noise floor for the silent segment.

% Modifying noise floor estimate (Section 6):
nF = 4*nF; % raising the threshold.

% peak detection for first time segment (Section 5.3):
peak_ind = peakDetec(S,nF,aNF,7); % peak detection function, it receives the spectrum, both thresholds, and the maximum number of peaks.

% Set pFlag to 1 to plot the spectrum, the thresholds, and the detected
% peaks.
pFlag = 0;
if(pFlag)
    init = 1; % First frame to be plotted
    for ii=init:size(S,2)
        plot(20*log10(abs(S(:,ii))));
        hold on;
        plot(20*log10(nF(:,ii)),'g--');
        plot(peak_ind{ii},20*log10(abs(S(peak_ind{ii},ii))),'og');
        plot(20*log10(aNF),'r--');
        title(['Frame: ' num2str(ii)]);
        hold off
        pause
    end
end

% refining frequency (Section 5.4):
f = QIFFT(S,peak_ind,f,dftLen,Fs1); % Quadratic interpolation function

% refining amplitude (Section 5.5):
S = ampEst(X,S,f,peak_ind,window,1,N,Fs1); % amplitude estimation function

% tracking partials (Section 5.6):
tr1 = pt(S,f,t,hop,peak_ind,dF,max_inactive_time,kappa,min_track_length);
 
% Post-processing: removing tracks

%-------------------------------------------------------------------------
% 3rd sub-band analysis

% signal:
x2 = xm{end-1};

% Sub-band Fs:
Fs2 = Fs./(2.^(N-2));

% Analysis parameters:

winLen = 40e-3; % window length in seconds.
% adjusting window length
% odd length only!
fLen = round(winLen*Fs2);
if(~mod(fLen,2)),
    fLen=fLen+1;
end

window = hann(fLen); % window

% Zero-padding factor:
maxError = maxFreqError(3,N); % Function that returns the maximum tolerable error given the sub-band.
ZP = zpfmin('hann',winLen,maxError); % Function that returns the zero-padding factor given the maximum erro and the analysis window.

% Defining maximum error
dftLen = 2^nextpow2(ZP*length(window));

% Partial tracking parameters:
dF = 0.005;
kappa = 0.25;
min_track_length = (250e-3);

% Analysis:

% stft
[S,t,f,X] = spec(x2,Fs2,hop,window,dftLen);

% obtaining noise floor estimate
nF = sse(abs(S),21);

% Noise floor profile estimate (based on silence segment):
aNF = nF(:,1:ceil(0.126/hop));
aNF = 3*mean(aNF,2);

% peak detection for first time segment:
nF = 4*nF;

peak_ind = peakDetec(S,nF,aNF,8);


% Set pFlag to 1 to plot the spectrum, the thresholds, and the detected
% peaks.
pFlag = 0;
if(pFlag)
    init = 1;
    for ii=init:size(S,2)
        plot(20*log10(abs(S(:,ii))));
        hold on;
        plot(20*log10(nF(:,ii)),'g--');
        plot(peak_ind{ii},20*log10(abs(S(peak_ind{ii},ii))),'og');
        plot(20*log10(aNF),'r--');
        title(['Frame: ' num2str(ii)]);
        hold off
        pause
    end
end

% refining frequency:
f = QIFFT(S,peak_ind,f,dftLen,Fs2);

% refining amplitude:
S = ampEst(X,S,f,peak_ind,window,2,N,Fs2);

% tracking partials:
tr2 = pt(S,f,t,hop,peak_ind,dF,max_inactive_time,kappa,min_track_length);

%-------------------------------------------------------------------------
% 2nd sub-band analysis

% signal:
x3 = xm{end-2};

% Sub-band Fs:
Fs3 = Fs./(2.^(N-3));

% Analysis parameters:

winLen = 40e-3; % window length in seconds.
% adjusting window length
% odd length only!
fLen = round(winLen*Fs3);
if(~mod(fLen,2)),
    fLen=fLen+1;
end

window = hann(fLen); % window

% Zero-padding factor:
maxError = maxFreqError(2,N); % Function that returns the maximum tolerable error given the sub-band.
ZP = zpfmin('hann',winLen,maxError); % Function that returns the zero-padding factor given the maximum erro and the analysis window.

% Defining maximum error
dftLen = 2^nextpow2(ZP*length(window));

% Partial tracking:
dF = 0.005;
kappa = 0.25;
min_track_length = (150e-3);

% Analysis:

% stft
[S,t,f,X] = spec(x3,Fs3,hop,window,dftLen);

% obtaining noise floor estimate
nF = sse(abs(S),41);

% Noise floor profile estimate (based on silence segment):
aNF = nF(:,1:ceil(0.126/hop));
aNF = 3*mean(aNF,2);
 
% peak detection for first time segment:
nF = 4*nF;

% Adjusting threshold to avoid detecting low-frequency peaks (that have
% already been detected by other sub-bands.
nF(1:215,:) = 10^(-50/20); % avoiding low-frequency peaks

nF(216:249,:) = 10^(-90/20); % adjusting to avoid sidelobes

% Adjusting the local threshold to avoid spurious peaks caused by some transient
% events
nF(274:279,382:390) = 0.1*nF(274:279,382:390);
nF(332:337,276:317) = 0.1*nF(332:337,276:317);
nF(348:352,303:320) = 0.1*nF(348:352,303:320);
nF(347:351,383:395) = 0.1*nF(347:351,383:395);
nF(418:424,380:396) = 0.1*nF(418:424,380:396);
nF(404:410,384:394) = 0.1*nF(404:410,384:394);
nF(434:438,383:393) = 0.1*nF(434:438,383:393);
nF(347:351,717:735) = 0.1*nF(347:351,717:735);
nF(419:424,717:731) = 0.1*nF(419:424,717:731);
nF(362:366,717:727) = 0.1*nF(362:366,717:727);
nF(406:410,721:727) = 0.1*nF(406:410,721:727);

% Adjusting threshold at the offset of the signal:
nF(:,1113:1210) = 0.5*nF(:,1113:1210);
nF(421:424,1118:1160) = 0.1*nF(421:424,1118:1160);
nF(347:351,1119:1170) = 0.1*nF(347:351,1119:1170);

peak_ind = peakDetec(S,nF,aNF,25); % peak detection

% Set pFlag to 1 to plot the spectrum, the thresholds, and the detected
% peaks.
pFlag = 0;
if(pFlag)
    init = 220; %first frame to be plotted
    for ii=init:size(S,2)
        plot(20*log10(abs(S(:,ii))));
        hold on;
        plot(20*log10(nF(:,ii)),'g--');
        plot(peak_ind{ii},20*log10(abs(S(peak_ind{ii},ii))),'og');
        plot(20*log10(aNF),'r--');
        title(['Frame: ' num2str(ii)]);
        hold off
        pause
    end
end

% refining frequency:
f = QIFFT(S,peak_ind,f,dftLen,Fs3);

% refining amplitude:
S = ampEst(X,S,f,peak_ind,window,3,N,Fs3);

% tracking partials:
tr3 = pt(S,f,t,hop,peak_ind,dF,max_inactive_time,kappa,min_track_length);


% post-processing:
tr3(17) = [];

%-------------------------------------------------------------------------
% 1st sub-band analysis

% signal:
x4 = xm{end-3};

% Sub-band Fs:
Fs4 = Fs./(2.^(N-4));

% Analysis parameters:

winLen = 40e-3; % window length in seconds.
% adjusting window length
% odd length only!
fLen = round(winLen*Fs4);
if(~mod(fLen,2)),
    fLen=fLen+1;
end

window = hann(fLen); % window

% Zero-padding factor:
maxError = maxFreqError(1,N); % Function that returns the maximum tolerable error given the sub-band.
ZP = zpfmin('hann',winLen,maxError); % Function that returns the zero-padding factor given the maximum erro and the analysis window.

% Defining maximum error
dftLen = 2^nextpow2(ZP*length(window));

% Partial tracking:
dF = 0.005;
kappa = 0.85;
min_track_length = (200e-3);

% Analysis:

% stft
[S,t,f,X] = spec(x4,Fs4,hop,window,dftLen);

% obtaining noise floor estimate
nF = sse(abs(S),101);

% Noise floor profile estimate (based on silence segment):
aNF = nF(:,1:ceil(0.126/hop));
aNF = 2*mean(aNF,2);

% Adjusting the local threshold:
nF = 1.1*nF;
 
nF(:,1:110) = 10^(-50/20); % avoiding silence at the beginning
nF(1:431,:) = 10^(-50/20); % avoiding low-frequency peaks
nF(432:520,:) = 10^(-100/20); % avoiding low-frequency peaks
nF(:,1200:end) = 10^(-50/20); % avoiding silence at the end
nF(965:end,:) = 10^(-50/20); % avoiding spurious high-frequency peaks


% Adjusting the threshold to avoid spurious peaks caused by transient
% events.


% 1st transient event
nF(:,300:320) = 0.5*nF(:,300:320);
nF(868:871,300:320) = 10*nF(868:871,300:320);
nF(882:886,307:320) = 10*nF(882:886,307:320);
nF(898:900,300:320) = 10*nF(898:900,300:320);
nF(810:813,300:320) = 10*nF(810:813,300:320);

% 2nd transient event
nF(:,380:400) = 0.75*nF(:,380:400);
nF(953:956,377:400) = 10*nF(953:956,377:400);
nF(960:964,377:400) = 10*nF(960:964,377:400);
nF(776:780,381:388) = 10*nF(776:780,381:388);
nF(776:782,389:400) = 10*nF(776:782,389:400);
nF(785:787,381:400) = 10*nF(785:787,381:400);

% 3rd transient event
nF(:,716:725) = 0.5*nF(:,716:725);
nF(634:639,721:727) = 10*nF(634:639,721:727);
nF(651:654,726:730) = 0.1*nF(651:654,726:730);
nF(712:715,720:727) = 10*nF(712:715,720:727);
nF(727:730,720:727) = 10*nF(727:730,720:727);
nF(697:700,719:725) = 10*nF(697:700,719:725);
nF(741:744,722:726) = 10*nF(741:744,722:726);
nF(764:767,717:726) = 10*nF(764:767,717:726);
nF(785:791,717:726) = 10*nF(785:791,717:726);
nF(799:801,717:726) = 10*nF(799:801,717:726);
nF(809:811,717:726) = 10*nF(809:811,717:726);
nF(814:817,728:732) = 10*nF(814:817,728:732);
nF(840:842,719:726) = 10*nF(840:842,719:726);
nF(845:848,727:728) = 10*nF(845:848,727:728);
nF(845:855,710:725) = 10*nF(845:855,710:725);
nF(860:863,714:725) = 10*nF(860:863,714:725);
nF(872:874,714:726) = 10*nF(872:874,714:726);
nF(951:956,714:726) = 10*nF(951:956,714:726);
nF(946:948,714:726) = 10*nF(946:948,714:726);
nF(931:935,714:726) = 10*nF(931:935,714:726);
nF(925:927,714:726) = 10*nF(925:927,714:726);
nF(960:964,714:726) = 10*nF(960:964,714:726);
nF(955:958,726:730) = 0.5*nF(955:958,726:730);


peak_ind = peakDetec(S,nF,aNF,140); % Peak detection

% Set pFlag to 1 to plot the spectrum, the thresholds, and the detected
% peaks.
pFlag = 0;
if(pFlag)
    init = 309; %determines the first frame to be plotted.
    for ii=init:size(S,2)
        plot(20*log10(abs(S(:,ii))));
        hold on;
        plot(20*log10(nF(:,ii)),'g--');
        plot(peak_ind{ii},20*log10(abs(S(peak_ind{ii},ii))),'og');
        plot(20*log10(aNF),'r--');
        title(['Frame: ' num2str(ii)]);
        hold off

        pause
    end
end

% refining frequency:
f = QIFFT(S,peak_ind,f,dftLen,Fs4);

% refining amplitude:
S = ampEst(X,S,f,peak_ind,window,4,N,Fs4);

% tracking partials:
tr4 = pt(S,f,t,hop,peak_ind,dF,max_inactive_time,kappa,min_track_length);

% Post-processing tracks:

tr = tr4;

%-------------------------------------------------------------------------
% Joining sub-bands tracks:
tr = [tr1 tr2 tr3 tr4];

% Interpolating and resampling the tracks (Section 5.7):
tr = interpTrack(tr,4);
tr = resampleTracks(tr,2e-3);

% Synthesizing obtained signals:
y = synth(tr);
wavwrite(y,44100,16,'Level1_accordion_synth');

%--------------------------------------------------------------------------
% Generating final spectrogram with superimposed tracks for visual
% inspection

winLen = 40e-3;

x = wavread('Level1_accordion.wav');

if(~mod(fLen,2)),
    fLen=fLen+1;
end
window = hann(fLen); % window
dftLen = 2.^nextpow2(fLen);
[S,t,f,X] = spec(x,Fs,hop,window,dftLen);
cut = 21000;
f = f(:,1);
ind =f<=cut;
f = f(ind);

imagesc(t(1,:),f(:,1),20*log10(abs(S(ind,:))));
axis xy;
hold on;

for ii=1:length(tr)
    plot(tr(ii).time,tr(ii).freq);
end
hold off;

%--------------------------------------------------------------------------
% Saving track structure:

% Saving a data strucutre with only the onsets:

% Saving tracks
for ii=1:length(tr)
    trMod(ii).onset = tr(ii).time(1);
    trMod(ii).freq = tr(ii).freq;
    trMod(ii).phase = tr(ii).freq;
    trMod(ii).amp = tr(ii).amp;
end
tr = trMod;


save Level1_accordion_tracks tr;

rmpath('./Scripts');