function S = ampEst(X,S,f,peaks,window,n,N,Fs)
% Amplitude Estimation Algorithm
%
% SHat = ampEst(X,S,f,peaks,window,n,N,Fs)
%
% where:
%
% X - matrix containg a frame of the signal at each column for the current
%     sub-band
% S - spectrum matrix
% f - estimated frequency of each detected peak
% peaks - detected peaks
% window - window function
% n - current sub-band
% N - total number of sub-bands
% Fs - sampling frequency of the sub-band

% Leonardo Nunes  - lonnes@lps.ufrj.br


n_hop = size(S,2);

X = X.*window(:,ones(1,n_hop));
Wm = ftransform(window,0);

load hd;
h = 2*downsample(h,2);

for ii = 1:size(S,2),% frames loop.

    x = X(:,ii);
    freqs = f(peaks{ii},ii)*(-2*pi/Fs);
    x_corr = ftransform(x,freqs)./Wm;
    if(n~=N)
        filtAmp = ftransform(h,freqs);
    else  % Last sub-band, no correction necessary
        filtAmp = 1;
    end
    S(peaks{ii},ii) = 2*x_corr./filtAmp;

end

function X = ftransform(x, w)
%
% Discrete Time Fourier Transform
%
% This functions calculate the DTFT of the vector x on the normalized
% angular frequency w. If w is a vector this function returns a vector
% containing the transforms of the vector x on frequencies w.
%
% W = ftransform(x, w);
% 
% Leonardo de Oliveira Nunes - lonnes@lps.ufrj.br
%
% Created on: 02/08/2005
% Last modified: 25/03/2006

w = w(:);
x = (x(:))';
K = length(w);
N = length(x);
n = (0:N-1);

n = n(ones(K,1),:);
w = w(:,ones(1,N));
x = x(ones(K,1),:);

X = sum(x.*exp(-j*w.*n),2);