function tr = resampleTracks(tr,T)
% Partial Track Parameters Resampling Algorithm
%
% trRe = resampleTracks(tr,T)
%
% where:
%
% tr - partial tracks whose parameters are to be resampled
% T - new sampling period (in s)
% trRe - partial tracks with resampled parameters

% Leonardo Nunes  - lonnes@lps.ufrj.br


% This function resamples the tracks to period T (in s). A linear
% interpolation algorithm is used.

for ii=1:length(tr)
    
    t = tr(ii).time;
    f = tr(ii).freq;
    phase = tr(ii).phase;
    amp = tr(ii).amp;
    
	ra = [];
    rf = [];
    rp = [];
    
    desiredT = 0:T:t(end);
    [val,ind] = min(abs(desiredT-t(1)));
    desiredT = desiredT(ind+1:end);
    
    rf = interp1(t,f,desiredT,'linear');
    ra = interp1(t,amp,desiredT,'linear');
    rp = interp1(t,phase,desiredT,'linear');
    
    tr(ii).phase = rp;
    tr(ii).freq = rf;
    tr(ii).amp = ra;
    tr(ii).time = desiredT;
    
end