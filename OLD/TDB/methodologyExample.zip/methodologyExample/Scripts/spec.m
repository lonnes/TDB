function [S,t,f,X_out] = spec(x,Fs,hop,window,dftLen)
% STFT algorithm
%
% [S,t,f,X_out] = spec(x,Fs,hop,window,dftLen)
%
% where:
%
% x - input signal
% Fs - sampling rate of the input signal
% hop - desired hop size (in s)
% window - chosen window
% dftLen - number of bins in the DFT
% S - spectrum matrix
% t - time (in s) of each frame index
% f - frequency (in Hz) of each DFT bin
% X_out - such as S = fft(X_out)

% Leonardo Nunes  - lonnes@lps.ufrj.br


% This function calculates the spectrum of a signal.
    x = x(:);

    % STFT parameters:
    hop = round(Fs*(hop));
    winLen = length(window);

    f_len = winLen;
    f_len_2 = (f_len-1)/2;

    % Obtaining the spectrum for the whole signal:
    nx = length(x); % Input signal length.
    n_hop = floor((nx)/hop)+1;  % Number of analysis frames.

    % Adjusting input signal length:
    x = [zeros(f_len_2,1);x;zeros((n_hop)*hop+f_len-nx,1)];

    colindex = (0:(n_hop-1))*(hop);
    rowindex = (1:f_len)';

    X = zeros(f_len,n_hop); % Matrix containing the frames at each column.

    % Filling the X matrix:
    X(:) = x(rowindex(:,ones(1,n_hop))+colindex(ones(f_len,1),:));
    X_out = X;

    % Windowing the signal:
    X = X.*window(:,ones(1,n_hop));

    % Zero phase windowing:
    n_z = floor((dftLen-f_len)/2);
    X = [zeros(n_z,n_hop);X;zeros(n_z+1,n_hop)];
    X = fftshift(X,1);

    % Calculating the sfft:
    S = fft(X,dftLen)/length(X);

    % Calculating the time and frequency vectors:
    aux = (hop/Fs);
    f = ((0:(dftLen/2))*(Fs/dftLen))';
    t = (0:n_hop-1)*(aux);
    t = t(ones(length(f),1),:);
    S = 2*S(1:length(f),:);
    f = f(:,ones(1,n_hop));