function tr = interpTrack(tr,p)
% Missing Data Interpolation Algorithm for Partial Tracks
%
% trInt = interpTrack(tr,p) 
%
% where:
%
% tr - partial tracks that have data that need to be interpolated
% p - interpolation order
% t - time (in s) associted with each frame index
% trInt - tracks afeter interpolation of missing data

% Leonardo Nunes - lonnes@lps.ufrj.br


F = 4;

tol = 1e-5;

for ii=1:length(tr)
    
    a = tr(ii).amp;
    f = tr(ii).freq;
    
    ind = find(a==-1);
    
    if(~isempty(ind))
        
        a(ind) = 0;
        f(ind) = 0;

        auxInd = ind(ind>(length(a)-p));
        ind(ind>(length(a)-p)) = [];

        a_int = ar_reconstruction(tol,p,F,ind,a.',[]);
        f_int = ar_reconstruction(tol,p,F,ind,f.',[]);
        
        % Obtaining points at the end of the track:
        a_int = a_int(end:-1:1);
        f_int = f_int(end:-1:1);
        
        N = length(a_int);
        
        a_int = ar_reconstruction(tol,p,F,N-auxInd+1,a_int,[]);
        f_int = ar_reconstruction(tol,p,F,N-auxInd+1,f_int,[]);
        
        a_int = a_int(end:-1:1);
        f_int = f_int(end:-1:1);
        
        ind = [ind auxInd];

%         subplot(211);
%         plot(a)
%         hold on
%         plot(a_int,'r')
%         plot(ind,a_int(ind),'k.')
%         xlabel('?ndice dos elementos da trilha')
%         ylabel ('valor do par?metro rastreado')
%         legend('com falha','original','interpolada')
%         hold off;
%         subplot(212);
%         plot(f)
%         hold on
%         plot(f_int,'r')
%         plot(ind,f_int(ind),'k.')
%         xlabel('?ndice dos elementos da trilha')
%         ylabel ('valor do par?metro rastreado')
%         legend('com falha','original','interpolada')
%         hold off
% 
%         pause
        
        tr(ii).amp = a_int;
        tr(ii).freq = f_int;
    end
    

end

function [x,a]=ar_reconstruction(tol,p,F,falhas,x,a)
% This function implements the AR-based signal reconstruction
% tol: is an error tolerance used for terminating the iterations
% p: AR model order
% F: maximum length (in samples) of a click allowed
% falhas: indices of samples in x that have considered as corrupted with
% clicks (obtained from detection function)
% x: input signal marred with clicks
% a: AR model computed during click detection stage

if ~isempty(falhas),   % checks whether there are clicks to suppress

    
    MaxIt = 1000; % maximum number of iterations!
    N=length(x);
    pmais1=p+1; 
    Nmenosp=N-p;
    maxNpF_mf=Nmenosp; 

    anta=zeros(p,1);   % previous coefficients of the AR model
    n=0;			   % iteration

    a=arburg(x(1:maxNpF_mf),p);  % current AR model estimation
    a(1)=[];
    a=a(:);
    a=-a;
    it=0; % iteration counter!
    % Performs signal reconstruction while the "differences" between the current and previous AR models are above tol  
    while ((norm(a-anta)/norm(a))>tol && it<=MaxIt)
       n=n+1;
       A=sparse(1:Nmenosp,pmais1:N,ones(1,Nmenosp),Nmenosp,N);
       for ii=1:p
          A=A+sparse(1:Nmenosp,(pmais1-ii):(N-ii),-a(ii)*ones(1,Nmenosp),Nmenosp,N);
       end
       falhasaux=[1:maxNpF_mf];
       
       falhasaux(falhas)=[];   

       Ad=A(1:maxNpF_mf-p,falhas);
       Ac=A(1:maxNpF_mf-p,falhasaux);
       clear A;  			   
       xc=x(falhasaux);
       clear falhasaux;
       Adt=Ad';  
       x(falhas)=-(Adt*Ad)\(Adt*(Ac*xc));    % LS AR interpolation
       clear Ad; 
       clear Ac; 
       anta=a;		% current AR model attributed to previous AR model vetor
       a=arburg(x(1:maxNpF_mf),p);   % estimates new (current)AR model from x with already suppressed clicks 
       a(1)=[];
       a=a(:);a=-a;
       it = it+1;
    end
end 

function ye = f_extrap(y,M,W)
% Forward extrapolation
a = arburg(y,M);
Z = filtic(1,a,y(end-(0:(M-1))));
ye = filter(1,a,zeros(1,W),Z);