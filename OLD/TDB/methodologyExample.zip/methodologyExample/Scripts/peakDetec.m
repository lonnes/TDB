function peak_ind = peakDetec(S,threshold,aNF,numPeaks)
% Peak detection function
%
% peak_ind = peakDetec(S,threshold,aNF,numPeaks)
%
% S - spectrum matrix
% threshold - local threshold
% aNF - global threshold
% numPeaks - limits the number of peaks that are detected
% peak_ind - detected peaks index at each frame (cell array)

% Leonardo Nunes - lonnes@lps.ufrj.br

    S = abs(S);

    % Applying threshold:
    mat_th = threshold;
    
    %S = S.*(S>=mat_th);

    % Finding the peaks:
    aux  = filter([1 -1],1,S);
    aux = sign(aux);
    aux = filter([1 -1],1,aux);

    [r,c] = find(aux==-2);

    % Creating the peaks cell array. 
    % Each cell contains the peaks index for a given frame.
    for ii = 1:size(S,2),
        ind = find(c==ii);
        peak_ind{ii} = r(ind)-1;
        
        % Selecting peaks above the threshold.
        peakAux = (S(peak_ind{ii},ii)<max(mat_th(peak_ind{ii},ii),aNF(peak_ind{ii})));

        
       peak_ind{ii}(peakAux) = [];
        
        % Discarding peaks!
        if(numPeaks)
            [aux,ind] = sort(S(peak_ind{ii},ii),1,'descend');
            peak_aux = peak_ind{ii}(ind);
            N = length(peak_aux); 
            peak_ind{ii} = peak_aux(1:min(numPeaks,N));
        end
    end