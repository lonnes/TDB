function maxErr = maxFreqError(n,N)
% Maximum tolerable frequency estimation error
%
% maxErr = maxFreqError(n,N)
%
% where:
%
% n - sub-band for which the maximum tolerable error is to be calculated
% N - total number of sub-bands
% maxErr - maximum tolerable error in Hz for the chosen sub-band

% Leonardo Nunes  - lonnes@lps.ufrj.br


Fs = 44100;

startF = (Fs/2)*2^(-n); % Sub-band last frequency
endF = (Fs/2)*2^(-n+1); % Sub-band first frequency

if(N==n)
    startF = 0;
end

% Creating an auxiliary frequency vector:
f = startF:0.1:endF; % 0.1 Hz steps


% Obtaining the JND for the desired frequency region:
a = 0.028;
b = -0.696;

LdF =((a*sqrt(f)+b));
df = (10.^(LdF));

% Choosing the maximum tolerable error (in %) as the minimum JND of the region:

maxErr = min(df);