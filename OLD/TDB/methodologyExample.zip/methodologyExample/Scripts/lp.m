function Y = lp(x,N)
% Laplacian Pyramid Algorithm
%
% y = lp(x,N)
%
% where:
%
% x - input signal (at 44.1 kHz)
% N - desired number of sub-bands
% Y - cell array containing the output of each sub-band
%
% The filter stored in the file hd.mat is used for the decomposition.

% Leonardo Nunes  - lonnes@lps.ufrj.br




% Laplacian pyramid algorithm for N sub-bands. 

Y = cell(N,1);
auxl = x;

%Fs = 44100;
% plot(x);sound(x,Fs);pause;
for ii=1:N-1,
    [auxl,auxh] = lpfilt(auxl);
    %plot(auxl);sound(auxl,Fs/2^(ii-1));plot(fftshift(20*log10(abs(fft(auxl)))));title(num2str(ii));pause;
    %plot(auxh);sound(auxh,Fs/2^(ii-1));title(num2str(ii));pause;
    Y{ii} = auxh;
end
% plot(auxh);sound(auxl,Fs/2^(N-1));title(num2str(N));pause;
Y{N} = auxl;

%--------------------------------------------------------------------------

function [yl,yh] = lpfilt(x)
% Laplacian Pyramid Structure filter
x = x(:);

load hd;

aux = [x;zeros((length(h)-1)/2,1)];

aux = filter(h,1,aux);
aux = aux(((length(h)-1)/2)+1:end);
yh = x-aux;
yl = downsample(aux,2);