function tracks = pt(S,f,t,hop,peaks_ind,dF,max_inactive_time,kappa,min_track_length)
% Partial Tracking algorithm
%
% tracks = pt(S,f,t,hop,peaks_ind,dF,max_inactive_time,kappa,min_track_length)
%
% where:
%
% S - spectrum matrix
% f - estimated frequency (in Hz) for each detected peak
% t - time (in s) associated with each frame index
% hop - chosen hop size
% peaks - detected peaks at each frame
% dF - maximum frequency variation allowed
% max_inactive_time - number of frames that a track can stay active even though
%                     it has not found a continuation
% kappa - controls the emphasis between amplitude and frequency distances
%         when choosing a continuation for a track
% min_track_length - minimum duration that a track can have (in s)
% tracks - partial tracks found


% Leonardo Nunes  - lonnes@lps.ufrj.br




f_len = hop;

pred_freq = []; % Predicted frequencies for the active tracks.
pred_amp = []; % Predicted frequencies for the active tracks.
active_vec = []; % Active tracks indexes.
tracks = []; % Tracks vector.
tracks_aux = []; % Auxiliary data for the tracks.

n_frames = size(S,2);


plotFlag = 0;
FigureN = 1;


for ff = 1:n_frames,
% Frame loop.

    peaks_freq = f(peaks_ind{ff},ff);
    peaks_time = (t(peaks_ind{ff},ff));
    peaks_amp = abs(S(peaks_ind{ff},ff));
    peaks_phase = angle(S(peaks_ind{ff},ff));
    
    % Sorting tracks according to amplitude:
    [pred_amp,auxI] = sort(pred_amp,2,'descend');
    pred_freq = pred_freq(auxI);
    active_vec = active_vec(auxI);

    remove_vec = [];
    
    
    
    for ii = 1:length(active_vec),

        kk = active_vec(ii);

        % Searching for track continuation:

        % 1) Selecting candidates:
        auxCand = (abs(pred_freq(ii)-peaks_freq)<= dF*pred_freq(ii));
        
        if(sum(auxCand))
        % Track continuation found:
        
            freqCand = peaks_freq(auxCand);
            ampCand = peaks_amp(auxCand);
            phaseCand = peaks_phase(auxCand);
            timeCand = peaks_time(auxCand);

            % 2) Selecting best candidate:
            bI = dec_fun(pred_freq(ii),freqCand,pred_amp(ii),ampCand,kappa);
            
            % Storing values:
            tracks(kk).time(end+1) = timeCand(bI);
            tracks(kk).freq(end+1) = freqCand(bI);
            tracks(kk).amp(end+1) = ampCand(bI);
            tracks(kk).phase(end+1) = phaseCand(bI);

            pred_freq(ii) = freqCand(bI);
            pred_amp(ii) = ampCand(bI);

            % Storing auxiliary data:
            tracks_aux(kk).sleep_time = 0;
            
            % Removing chosen peak:
            pI = find(freqCand(bI)==peaks_freq);
            peaks_freq(pI) = [];
            peaks_amp(pI) = [];
            peaks_time(pI) = [];
            peaks_phase(pI) = [];

        else
        % Track continuation not found:
            if(tracks_aux(kk).sleep_time+1>=max_inactive_time),
            % This track is inactive and is removed from the active tracks vec.
                remove_vec(end+1) = kk;
            end

            % Storing values:
            tracks(kk).time(end+1) = tracks(kk).time(end)+ hop;
            tracks(kk).freq(end+1) = tracks(kk).freq(end);
            tracks(kk).amp(end+1) = -1;
            tracks(kk).phase(end+1) = tracks(kk).phase(end);

            % Storing auxiliary data:
            tracks_aux(kk).sleep_time = tracks_aux(kk).sleep_time+1;
            %tracks_aux(kk).sleep_time
        end

    end
    
%    peaks_freq

    % Finding the unassigned peaks:
    for jj = 1:length(peaks_amp),

        % Storing values:
        tracks(end+1).time = peaks_time(jj);
        tracks(end).freq = peaks_freq(jj);
        tracks(end).amp = peaks_amp(jj);
        tracks(end).phase = peaks_phase(jj);

        tracks_aux(end+1).sleep_time = 0;

        active_vec(end+1) = length(tracks);
        pred_freq(end+1) = peaks_freq(jj);
        pred_amp(end+1) = peaks_amp(jj);

    end

    for ii = 1:length(remove_vec),
        
        jj = remove_vec(ii);
        kk = find(active_vec==jj);

        % Removing the track from the active tracks vector.
        active_vec(kk) = [];
        pred_freq(kk) = [];
        pred_amp(kk) = [];
        
        % Removing the dummy points inserted on the track.
        tracks(jj).time(end-max_inactive_time+1:end) = [];
        tracks(jj).freq(end-max_inactive_time+1:end) = [];
        tracks(jj).amp(end-max_inactive_time+1:end) = [];
        tracks(jj).phase(end-max_inactive_time+1:end) = [];
    end

    %-----plotting---------
    if(plotFlag&&(ff+1<size(f,2))),
        figure(FigureN);
        title(num2str(ff));
        aux = min(length(tracks(active_vec(1)).freq),10);
        plot(ff-aux+1:ff,tracks(active_vec(1)).freq(end-aux+1:end));
        hold on;
        plot(ff:ff+1,[tracks(active_vec(1)).freq(end) pred_freq(1)],'r');
        plot(ff+1,pred_freq(1),'rx');
        plot(ff+1*ones(size(f(peaks_ind{ff+1},ff+1))),f(peaks_ind{ff+1},ff+1),'o');
        for jj=2:length(active_vec),
            aux = min(length(tracks(active_vec(jj)).freq),10);
            plot(ff-aux+1:ff,tracks(active_vec(jj)).freq(end-aux+1:end));
            plot(ff:ff+1,[tracks(active_vec(jj)).freq(end) pred_freq(jj)],'r');
            plot(ff+1,pred_freq(jj),'rx');
        end
        hold off;
        %pause;
    end

end

% Removing short tracks:
rem_ind = [];
for ii=1:length(tracks),
    %tracks(ii).time(end)-tracks(ii).time(1)
    if((tracks(ii).time(end)-tracks(ii).time(1))<min_track_length),
        rem_ind(end+1) = ii;
    end
end

tracks(rem_ind) = [];
tracks_aux(rem_ind) = [];

function bI = dec_fun(tFreq,cFreq,tAmp,cAmp,kappa)

freqDiff = abs((tFreq-cFreq)./tFreq);
ampDiff = abs((tAmp-cAmp)./tAmp);

met = (1-kappa)*freqDiff+kappa*ampDiff;

[y,bI] = min(met);

