function f = QIFFT(S,peak_ind,f,K,Fs)
% Frequency estimation via quadratic interpolation
%
% fHat = QIFFT(S,peak_ind,f,K,Fs)
%
% where:
%
% S - spectrum matrix
% peak_ind - detected peaks indexes
% f - frequency (in Hz) associated with each DFT bin
% K - DFT length
% Fs - sampling frequency
% fHat - estimated frequency (in Hz) for each detected peak

% Leonardo Nunes - lonnes@lps.ufrj.br

for ii=1:length(peak_ind)

    f_aux = peak_ind{ii};
    X = abs(S(:,ii));

    for jj = 1:length(f_aux)
        indMax = f_aux(jj);

        if(indMax==1)
            [p,y,a] = qint(X(indMax+1),X(indMax),X(indMax+1));
        elseif(indMax==length(X))
            [p,y,a] = qint(X(indMax-1),X(indMax),X(indMax-1));
        else
            [p,y,a] = qint(X(indMax-1),X(indMax),X(indMax+1));
        end
        
        f(indMax,ii) = f(indMax,ii)+p*(Fs/K);
        
    end

end

function [p,y,a] = qint(ym1,y0,yp1) 
% quadratic interpolation.

   p = (yp1 - ym1)/(2*(2*y0 - yp1 - ym1)); 
   if nargout>1
     y = y0 - 0.25*(ym1-yp1)*p;
   end;
   if nargout>2
     a = 0.5*(ym1 - 2*y0 + yp1);
   end;
