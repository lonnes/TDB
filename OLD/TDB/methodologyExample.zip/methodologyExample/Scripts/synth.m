function x = synth(tr)
% Synthesis algorithm
%
% x = synth(tr)
%
% where:
%
% tr - partial track strucutre
% x - synhtesized signal at 44.1 kHz

% Leonardo Nunes  - lonnes@lps.ufrj.br


% This function synthesizes a signal give its sinusoidal tracks. The signal
% is always sampled at 44.1 kHz


% Created: 16/01/2007
% Modified: 13/04/2008

%------------------------------------------------------------------------------
% Variables:
max_len = 0; % Maximun length found.
x = [];

%--------------------------------------------------------------------------


fs = 44100;
tracks = tr;
T = 1/fs;

% Track loop;
for kk=1:length(tracks),
    
    time_vec = tracks(kk).time;
    amp_vec = tracks(kk).amp;
    freq_vec = tracks(kk).freq;
    phase_vec = tracks(kk).phase;
    
    time_vec = time_vec(:);
    amp_vec = amp_vec(:);
    freq_vec = freq_vec(:);
    phase_vec = phase_vec(:);
    
    if(time_vec(1)-2e-3 > 0)
        time_vec = [time_vec(1)-2e-3;time_vec;time_vec(end)+2e-3];
        amp_vec = [0;amp_vec;0];
        freq_vec = [freq_vec(1);freq_vec;freq_vec(end)];
        phase_vec = [phase_vec(1);phase_vec;phase_vec(end)];
    elseif(time_vec(1)==0)
        time_vec = [time_vec;time_vec(end)+2e-3];
        amp_vec = [amp_vec;0];
        freq_vec = [freq_vec;freq_vec(end)];
        phase_vec = [phase_vec;phase_vec(end)];
    end
        

    tr_first_sample = round(time_vec(1)*fs);
    tr_final_sample = round(time_vec(end)*fs);

    if(max_len<tr_final_sample),
        max_len = tr_final_sample;
        x = [x;zeros(max_len-length(x)+1,1)];
    end

    n = time_vec(1):T:time_vec(end);
    f_n = time_vec;

    % Interpolating the functions in time:
    inter_amp = interp1(f_n,amp_vec,n,'linear');
    inter_freq = interp1(f_n,freq_vec,n,'linear');
    inter_amp = max(inter_amp,1e-6);

    % Integrating using trapezoids.
    aux = phase_vec(1); % Initial phase.
    f_m = zeros(1,length(inter_freq));
    f_m(1) = aux;

    for ii = 2:length(inter_freq),
        aux = aux + (inter_freq(ii)+inter_freq(ii-1))/(2*fs);
        f_m(ii) = aux;
    end

    x_aux = inter_amp.*cos((2*pi*(f_m))); % Synthesizing the track.

    % Adjusting the track length:
    x_aux = [zeros(tr_first_sample,1);x_aux';zeros(max_len-length(x_aux)-tr_first_sample+1,1)];

    if(kk~=1),
        x = x+x_aux;
    else
        x = x_aux;
    end
end