function [nF] = sse(S,f_len)
% Noise floor estimation function
%
% nF = sse(S,f_len)
%
% where:
%
% S - spectrum matrix
% f_len - smoothing filter length
% nF - estimated noise floor for each frame

% Leonardo Nunes  - lonnes@lps.ufrj.br


% Extending spectrum:
s_len = size(S,1);
nfft = 2*(s_len-1);
e_points = round(nfft/40); % Setting number of extension points as 1/20 of spectrum length.
ini_s = flipud(S(1:e_points,:));
end_s = (S(s_len-(0:(e_points-1)),:));
eS = [ini_s;S;end_s];     % extended magnitude spectrum to avoid boundary problems

% First average filter:
eS = filter([1 1 1]/3,1,eS);

% Reciprocal spectrum:
eS = eS.^-1;

h=ones(f_len,1)./f_len;
S_o = filter(h,1,eS);
S_o = S_o(e_points+(1:s_len),:);

% Obtainig noise floor estimate:
nF = S_o.^-1;