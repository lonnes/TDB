% Analysis script -- Level 1 -- accordion analysis

clear all;

addpath('./Scripts'); % This directory contains auxiliary functions, e.g. STFT function.

% Reading the wavefile and the sampling rate:
[x,Fs] = wavread('Level1_accordion.wav');

%-----------------------------
% Defining analysis parameters common to all subbands:

% Initial number of subbands (Section 6):
N = 4;

% Defining the frame hop size (in ms) (defines sampling rate of the parameters of the track):
hop = 2e-3; % hop size (Section 4.1)

% The following parameter defines the maximum number of consecutive missing
% data in a given track (Section 4.1):
max_inactive_time = 4;
%-----------------------------

% Dividing the signal into N subbands (Section 5.1):
xm = sd(x,N); % This function decomposes the signal in N (redundant) subbands.

%-------------------------------------------------------------------------
% Preliminary analysis -- uncomment to plot the spectrogram of the signal

% Checking silences and number of subbands needed.
%winLen = 40e-3;
%fLen = round(winLen*Fs);
%if(~mod(fLen,2)),
%	fLen=fLen+1;
%end
%window = hann(fLen); % window
%dftLen = 2.^nextpow2(fLen);
%[S,t,f] = spec(x,Fs,hop,window,dftLen);
%
%imagesc(t(1,:),f(:,1),20*log10(abs(S)));
%xlabel('Time (s)');
%ylabel('Frequency (Hz)');
%
%axis xy;
%return
%

%-------------------------------------------------------------------------
% 4th subband analysis

% Subband signal:
x4 = xm{end};

% Subband sampling rate:
Fs4 = Fs./(2.^(N-1));

% Highest frequency (in Hz) of the subband that is employed during the analysis:
maxSubbandFreq = 0.8*Fs4*0.5; 

% Lowest frequency (in Hz) of the subband that is employed during the analysis:
minSubbandFreq = 20; 

% Analysis parameters for this subband:

winLen = 40e-3; % window length in seconds.
% adjusting window length
% odd length only!
fLen = round(winLen*Fs4);
if(~mod(fLen,2)),
    fLen=fLen+1;
end

window = hann(fLen); % using Hann window (Section 5.2)

% Obtaining the zero-padding factor:
maxError = maxFreqError(minSubbandFreq,maxSubbandFreq); % Function that returns the maximum tolerable error (in Hz) given the subband (Section 4.2.1).
ZP = zpfmin('hann',winLen,maxError); % Function that returns the zero-padding factor given the maximum tolerable error and the analysis window (Section 5.4). 

% Defining DFT length (Sections 5.2 and 5.4):
dftLen = 2^nextpow2(ZP*length(window));

% Partial tracking parameters (Section 5.6):
dF = 0.05;
kappa = 0.01;
min_track_length = (100e-3);

% Analysis:

% STFT (Section 5.2)
[S,t,f] = spec(x4,Fs4,hop,window,dftLen); % This function estimates the complex spectrogram of the subband signal.
% S -- matrix with the complex spectrogram of each frame (more information in the help of the "spec" function)
% t -- time in seconds associated with each frame index (more information in the help of the "spec" function)
% f -- frequency in Hz corresponding to each bin index (more information in the help of the "spec" function)

% Removing redundant bins:
keepBins = (f(:,1)<=maxSubbandFreq)&(f(:,1)>minSubbandFreq);
S = S(keepBins,:);
f = f(keepBins,:);

% Obtaining noise floor estimate (Section 5.3):
nF = sse(abs(S),31); % Stochastic Spectrum Estimation method using a filter with 31 taps.

% Noise floor profile estimate (based on noise-only excerpt) (Section 5.3):
aNF = nF(:,1:ceil(0.126/hop));
aNF = 3*mean(aNF,2); % global threshold is 3 times the estimated noise floor.

% Modifying noise floor estimate (Section 6):
nF = 2.5*nF;

% Peak detection (Section 5.3):
peak_ind = peakDetec(S,nF,aNF); % Peak detection function: it receives the complex spectrogram and both thresholds.

% Set pFlag to 1 to plot the spectrum, the thresholds, and the detected
% peaks.
pFlag =0;
if(pFlag)
    init = 1198; % First frame to be plotted
    for ii=init:size(S,2)
        plot(20*log10(abs(S(:,ii))));
        hold on;
        plot(20*log10(nF(:,ii)),'g--');
        plot(20*log10(aNF),'r--');
        plot(peak_ind{ii},20*log10(abs(S(peak_ind{ii},ii))),'og');
        title(['Frame: ' num2str(ii)]);
        xlabel('Frequency bin index');
        ylabel('Magnitude (dB)')
        legend('Spectrum','Local threshold','Global threshold','Detected peaks');
        hold off
        pause
    end
end

% Refining frequency (Section 5.4):
[f,S] = QIFFT(S,peak_ind,f,dftLen,Fs4); % Quadratic interpolation function

% Tracking partials (Section 5.6):
tr4 = pt(S,f,t,hop,peak_ind,dF,max_inactive_time,kappa,min_track_length);
 
% Post-processing: removing tracks deemed incorrect after visual inspection
tr4(7) = [];

%-------------------------------------------------------------------------
% 3rd subband analysis

% Subband signal:
x3 = xm{end-1};

% Subband sampling rate:
Fs3 = Fs./(2.^(N-2));

maxSubbandFreq = 0.81*Fs3*0.5; % Highest frequency (in Hz) of the subband that is employed during the analysis.
minSubbandFreq = 0.35*Fs3*0.5; % Lowest frequency (in Hz) of the subband that is employed during the analysis.

% Analysis parameters:

winLen = 40e-3; % window length in seconds.
% adjusting window length
% odd length only!
fLen = round(winLen*Fs3);
if(~mod(fLen,2)),
    fLen=fLen+1;
end

window = hann(fLen); % window

% Obtaining the zero-padding factor:
maxError = maxFreqError(minSubbandFreq,maxSubbandFreq); % Function that returns the maximum tolerable error (in Hz) given the subband (Section 4.2.1).
ZP = zpfmin('hann',winLen,maxError); % Function that returns the zero-padding factor given the maximum error and the analysis window.

% Defining DFT length:
dftLen = 2^nextpow2(ZP*length(window));

% Partial tracking parameters:
dF = 0.005;
kappa = 0.25;
min_track_length = (250e-3);

% Analysis:

% STFT
[S,t,f] = spec(x3,Fs3,hop,window,dftLen);

% Removing redundant bins:
keepBins = (f(:,1)<=maxSubbandFreq)&(f(:,1)>minSubbandFreq);
S = S(keepBins,:);
f = f(keepBins,:);

% Obtaining noise floor estimate
nF = sse(abs(S),21);

% Noise floor profile estimate (based on noise-only segment):
aNF = nF(:,1:ceil(0.126/hop));
aNF = 3*mean(aNF,2);

% Adjusting noise floor:
nF = 3*nF;

% Peak detection (Section 5.3):
peak_ind = peakDetec(S,nF,aNF);

% Set pFlag to 1 to plot the spectrum, the thresholds, and the detected
% peaks.
pFlag = 0;
if(pFlag)
    init = 1; % First frame to be plotted
    for ii=init:size(S,2)
        plot(20*log10(abs(S(:,ii))));
        hold on;
        plot(20*log10(nF(:,ii)),'g--');
        plot(20*log10(aNF),'r--');
        plot(peak_ind{ii},20*log10(abs(S(peak_ind{ii},ii))),'og');
        title(['Frame: ' num2str(ii)]);
        xlabel('Frequency bin index');
        ylabel('Magnitude (dB)')
        legend('Spectrum','Local threshold','Global threshold','Detected peaks');
        hold off
        pause
    end
end

% Refining track parameters:
[f,S] = QIFFT(S,peak_ind,f,dftLen,Fs3);

% Tracking partials:
tr3 = pt(S,f,t,hop,peak_ind,dF,max_inactive_time,kappa,min_track_length);

%-------------------------------------------------------------------------
% 2nd subband analysis

% Subband signal:
x2 = xm{end-2};

% Subband sampling rate:
Fs2 = Fs./(2.^(N-3));

maxSubbandFreq = 0.8*Fs2*0.5; % Highest frequency (in Hz) of the subband that is employed during the analysis.
minSubbandFreq = 0.4*Fs2*0.5; % Lowest frequency (in Hz) of the subband that is employed during the analysis.

% Analysis parameters:
winLen = 40e-3; % window length in seconds.
% adjusting window length
% odd length only!
fLen = round(winLen*Fs2);
if(~mod(fLen,2)),
    fLen=fLen+1;
end

window = hann(fLen); % window

% Obtaining the zero-padding factor:
maxError = maxFreqError(minSubbandFreq,maxSubbandFreq); % Function that returns the maximum tolerable error (in Hz) given the subband (Section 4.2.1).
ZP = zpfmin('hann',winLen,maxError); % Function that returns the zero-padding factor given the maximum error and the analysis window.

% Defining DFT length:
dftLen = 2^nextpow2(ZP*length(window));

% Partial tracking:
dF = 0.005;
kappa = 0.25;
min_track_length = (250e-3);

% Analysis:

% STFT
[S,t,f] = spec(x2,Fs2,hop,window,dftLen);

% Removing redundant bins:
keepBins = (f(:,1)<=maxSubbandFreq)&(f(:,1)>minSubbandFreq);
S = S(keepBins,:);
f = f(keepBins,:);

% Obtaining noise floor estimate
nF = sse(abs(S),71);

% Noise floor profile estimate (based on noise-only segment):
aNF = nF(:,1:ceil(0.126/hop));
aNF = 3*mean(aNF,2);

% Adjusting noise floor:
nF = 2*nF;

% Raising threshold at the beginning of the signal:
nF(:,1:125) = nF(:,1:125)*2;
 
% Peak detection:
peak_ind = peakDetec(S,nF,aNF);

% Locally adjusting the threshold:
nF(143:148,1110:1190) = nF(143:148,1110:1190)/10; %  lowering the threshold to correctly track the offset of a track.

% Set pFlag to 1 to plot the spectrum, the thresholds, and the detected
% peaks.
pFlag = 0;
if(pFlag)
    init = 1110; % First frame to be plotted
    for ii=init:size(S,2)
        plot(20*log10(abs(S(:,ii))));
        hold on;
        plot(20*log10(nF(:,ii)),'g--');
        plot(20*log10(aNF),'r--');
        plot(peak_ind{ii},20*log10(abs(S(peak_ind{ii},ii))),'og');
        title(['Frame: ' num2str(ii)]);
        xlabel('Frequency bin index');
        ylabel('Magnitude (dB)')
        legend('Spectrum','Local threshold','Global threshold','Detected peaks');
        hold off
        pause
    end
end

% Refining track parameters:
[f,S] = QIFFT(S,peak_ind,f,dftLen,Fs2);

% Tracking partials:
tr2 = pt(S,f,t,hop,peak_ind,dF,max_inactive_time,kappa,min_track_length);

%-------------------------------------------------------------------------
% 1st subband analysis

% Subband signal:
x1 = xm{1};

% Subband sampling rate:
Fs1 = Fs./(2.^(N-4));
maxSubbandFreq = Fs1*0.5; % Highest frequency (in Hz) of the subband that is employed during the analysis.
minSubbandFreq = 0.4*Fs1*0.5; % Lowest frequency (in Hz) of the subband that is employed during the analysis.
 
% Analysis parameters:

winLen = 40e-3; % window length in seconds.
% adjusting window length
% odd length only!
fLen = round(winLen*Fs1);
if(~mod(fLen,2)),
    fLen=fLen+1;
end

window = hann(fLen); % window

% Obtaining the zero-padding factor:
maxError = maxFreqError(minSubbandFreq,maxSubbandFreq); % Function that returns the maximum tolerable error (in Hz) given the subband (Section 4.2.1).
ZP = zpfmin('hann',winLen,maxError); % Function that returns the zero-padding factor given the maximum error and the analysis window.

% Defining DFT length:
dftLen = 2^nextpow2(ZP*length(window));

% Partial tracking:
dF = 0.0025;
kappa = 1;
min_track_length = (100e-3);

% Analysis:

% STFT
[S,t,f] = spec(x1,Fs1,hop,window,dftLen);

% Removing redundant bins:
keepBins = (f(:,1)<=maxSubbandFreq)&(f(:,1)>minSubbandFreq);
S = S(keepBins,:);
f = f(keepBins,:);

% Obtaining noise floor estimate:
nF = sse(abs(S),71);

% Noise floor profile estimate (based on noise-only segment):
aNF = nF(:,1:ceil(0.126/hop));
aNF = 3*mean(aNF,2);

% Adjusting the local threshold:
nF = 2*nF;


% Raising threshold at the beginning and end of the signal:
nF(:,1:90) = nF(:,1:90)*10;
nF(:,1200:end) = nF(:,1200:end)*10;

% Modifying locally the threshold:
nF(:,260:406) = nF(:,260:406)/3;
nF(1:272,299:420) = nF(1:272,299:420)*3.0;
nF(273:end,310:420) = nF(273:end,310:420)*1.5;
nF(161:170,303:320) = nF(161:170,303:320)*10;
nF(358:364,223:230) = nF(358:364,223:230)/10;
nF(488:492,230:239) = nF(488:492,230:239)/10;
nF(374:376,378:385) = nF(374:376,378:385)*10;
nF(127:130,385:390) = nF(127:130,385:390)/10;
nF(473:476,307:322) = nF(473:476,307:322)*10;
nF(54:57,300:330) = nF(54:57,300:330)/10;
nF(126:130,300:330) = nF(126:130,300:330)/10;
nF(55:57,380:390) = nF(55:57,380:390)/10;
nF(8:11,380:400) = nF(8:11,380:400)/10;
nF(560:562,627:627) = nF(560:562,627:627)*10;
nF(:,719:740) = nF(:,719:740)/3;
nF(1:127,717:740) = nF(1:127,717:740)*1.5;
nF(536:540,717:730) = nF(536:540,717:730)*5;
nF(531:533,731:740) = nF(531:533,731:740)*5;
nF(:,1117:1130) = nF(:,1117:1130)/3;
nF(284:287,716:725) = nF(284:287,716:725)*10;
nF(458:461,305:321) = nF(458:461,305:321)*10;
nF(561:end,300:330) = nF(561:end,300:330)*10;
nF(526:531,301:310) = nF(526:531,301:310)*5;
nF(485:489,319:321) = nF(485:489,319:321)/10;
nF(523:530,311:324) = nF(523:530,311:324)*10;
nF(490:495,303:320) = nF(490:495,303:320)*10;
nF(489:492,322:325) = nF(489:492,322:325)/10;
nF(486:488,323:325) = nF(486:488,323:325)*10;
nF(418:421,392:395) = nF(418:421,392:395)*10;
nF(373:375,717:720) = nF(373:375,717:720)/10;
nF(512:end,716:718) = nF(512:end,716:718)/1.5;
nF(543:end,721:730) = nF(543:end,721:730)*5;

% Peak detection:
peak_ind = peakDetec(S,nF,aNF,100);

% Set pFlag to 1 to plot the spectrum, the thresholds, and the detected
% peaks.
pFlag = 0;
if(pFlag)
    init = 710; % First frame to be plotted
    for ii=init:size(S,2)
        plot(20*log10(abs(S(:,ii))));
        hold on;
        plot(20*log10(nF(:,ii)),'g--');
        plot(20*log10(aNF),'r--');
        plot(peak_ind{ii},20*log10(abs(S(peak_ind{ii},ii))),'og');
        title(['Frame: ' num2str(ii)]);
        xlabel('Frequency bin index');
        ylabel('Magnitude (dB)')
        legend('Spectrum','Local threshold','Global threshold','Detected peaks');
        hold off
        pause
    end
end

% Refining frequency:
[f,S] = QIFFT(S,peak_ind,f,dftLen,Fs1);

% Tracking partials:
tr1 = pt(S,f,t,hop,peak_ind,dF,max_inactive_time,kappa,min_track_length);

%-------------------------------------------------------------------------
% Joining subbands tracks:
tr = [tr4 tr3 tr2 tr1];

% Post-processing: removing tracks deemed incorrect after visual inspection
tr([62 67 68 71 74 75 76 77 78 79]) = [];

% Interpolating and resampling the tracks (Section 5.7):
tr = interpTrack(tr,4);
tr = resampleTracks(tr,2e-3);

% Synthesizing obtained signal:
y = synth(tr);

% Saving synthesized signal:
wavwrite(y,Fs,16,'Level1_accordion_synth.wav');

%--------------------------------------------------------------------------
% Generating final spectrogram with superimposed tracks for visual
% inspection

winLen = 40e-3;

x = wavread('Level1_accordion.wav');


fLen = round(winLen*Fs);

if(~mod(fLen,2)),
    fLen=fLen+1;
end
window = hann(fLen); % window
dftLen = 2.^nextpow2(fLen);
[S,t,f] = spec(x,Fs,hop,window,dftLen);
cut = 22000; % Highest frequency that should be shown
f = f(:,1);
ind =   (f>=20 )& (f<=cut);
f = f(ind);

imagesc(t(1,:),f(:,1),20*log10(abs(S(ind,:))));
axis xy;
hold on;

for ii=1:length(tr)
    plot(tr(ii).time,tr(ii).freq);
end

xlabel('Time (s)');
ylabel('Frequency (Hz)');
hold off;

%--------------------------------------------------------------------------
% Saving track structure:

% Saving a data structure with only the onsets:
for ii=1:length(tr)
    trMod(ii).onset = tr(ii).time(1);
    trMod(ii).freq = tr(ii).freq;
    trMod(ii).phase = tr(ii).phase;
    trMod(ii).amp = tr(ii).amp;
end
tr = trMod;

save Level1_accordion_tracks tr;

rmpath('./Scripts'); % Removing folder containing the scripts from the Matlab path.