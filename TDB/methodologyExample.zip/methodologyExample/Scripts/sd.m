function Y = sd(x,N)
% Subband Decompositon (with redundancy) Algorithm
%
% y = sd(x,N)
%
% where:
%
% x - input signal vector
% N - desired number of sub-bands
% Y - cell array containing the output of each sub-band
%
% The filter stored in the file hd.mat is used for the decomposition.

% Leonardo Nunes  - lonnes@lps.ufrj.br

% Initializing output cell array:
Y = cell(N,1);

% Auxiliary variable containing the output of the previous sub-band:
% for the first sub-band, it is the input signal itself.
auxl = x(:);

% Loading filter coefficients:
load hd;

for ii=1:N-1, %For each iteration, the signal at  subband ii is obtained.
 
    Y{ii} = auxl; % Storing subband signal.
    
    % Zero-phase filtering of input signal:
    aux = filtfilt(h,1,auxl); % avoids phase distortion
    
    % Downsampling signal:
    auxl= downsample(aux,2);
end

% Assigning signal at last subband:
Y{N} = auxl;