function maxErr = maxFreqError(startF,endF)
% Maximum tolerable frequency estimation error
%
% maxErr = maxFreqError(startF,endF)
%
% where:
%
% startF -  lowest frequency (in Hz) to be considered for the calculation of the JND.
% endF - highest frequency (in Hz) to be considered for the calculation of the JND.
% maxErr - maximum tolerable error in Hz for the frequency region defined by [startF,endF].

% Leonardo Nunes  - lonnes@lps.ufrj.br

% Creating an auxiliary frequency vector:
f = startF:0.1:endF; % in steps of 0.1 Hz

% Obtaining the JND for the desired frequency region:

% Parameters for frequency JND estimation:
a = 0.028;
b = -0.696;

% JND calculation:
LdF =((a*sqrt(f)+b));
df = (10.^(LdF));

% Choosing the maximum tolerable error (in Hz) as the minimum JND in the
% region of interest:
maxErr = min(df);