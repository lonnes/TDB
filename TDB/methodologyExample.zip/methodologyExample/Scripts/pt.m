function tracks = pt(S,f,t,hop,peaks_ind,dF,max_sleep_time,kappa,min_track_length)
% Partial Tracking algorithm
%
% tracks = pt(S,f,t,hop,peaks_ind,dF,max_inactive_time,kappa,min_track_length)
%
% where:
%
% S - complex spectrogram matrix
% f - estimated frequency (in Hz) of all DFT bins
% t - time (in s) associated with each frame index
% hop - chosen hop size
% peaks - indices of detected peaks at each frame
% dF - maximum frequency variation allowed
% max_sleep_time - number of frames that a track can stay forcefully active even though
%                  it has not found a continuation
% kappa - weight that controls the emphasis between amplitude and frequency distances
%         when choosing a continuation for a track. 0 <= kappa <= 1
% min_track_length - minimum length that a track must have (in s) in order to be considered valid
% tracks - partial tracks found


% Leonardo Nunes  - lonnes@lps.ufrj.br

f_len = hop;

pred_freq = []; % Zeroth-order predicted frequencies for the active tracks.
pred_amp = []; % Zeroth-order predicted amplitudes for the active tracks.
active_vec = []; % Indices of active tracks.
tracks = []; % Each element of this vector will contain a partial track.
tracks_aux = []; % Each element of this vector will contain ancillary information for a partial track.

n_frames = size(S,2); % Total number of frames.

for ff = 1:n_frames, % Loop over the analysis frame.


	% Reading the information related to the peaks detected at frame ff:
    peaks_freq = f(peaks_ind{ff},ff);
    peaks_time = t(peaks_ind{ff},ff);
    peaks_amp = abs(S(peaks_ind{ff},ff));
    peaks_phase = angle(S(peaks_ind{ff},ff));
    
    % Sorting tracks according to the last attributed amplitude:
    [pred_amp,auxI] = sort(pred_amp,2,'descend'); % this way the tracks with largest amplitude at the last frame select their continuation first.
    active_vec = active_vec(auxI);
    pred_freq = pred_freq(auxI);
    
    
    % Auxiliary vector: indicates which tracks should be removed from the
    % active track vector in the current frame.
    remove_vec = []; % Initial value: no track to be deleted.
    
    for ii = 1:length(active_vec),
        % Loop over active tracks at this given frame: at each iteration the following code looks for
        % the continuation  of one active track at frame ff.

        % Indice of the active track that is currently being updated:
        kk = active_vec(ii);

        % Searching for track continuation:

        % 1) Selecting candidates:
        auxCand = (abs(pred_freq(ii)-peaks_freq)<= dF*pred_freq(ii)); % uses both amplitutde and frequency information to find possible continuation for each track.
        
        if(sum(auxCand))
        % Track continuation found:
        
            % Extracting candidate peak parameter estimation.
            freqCand = peaks_freq(auxCand);
            ampCand = peaks_amp(auxCand);
            phaseCand = peaks_phase(auxCand);
            timeCand = peaks_time(auxCand);

            % 2) Selecting best candidate:
            bI = dec_fun(pred_freq(ii),freqCand,pred_amp(ii),ampCand,kappa); % Best peak continuation 
            
            % Storing values:
            tracks(kk).time(end+1) = timeCand(bI);
            tracks(kk).freq(end+1) = freqCand(bI);
            tracks(kk).amp(end+1) = ampCand(bI);
            tracks(kk).phase(end+1) = phaseCand(bI);

            % Updating the zeroth-order prediction for amplitude and frequency trajectories of the current active track: 
            pred_freq(ii) = freqCand(bI);
            pred_amp(ii) = ampCand(bI);

            % Storing auxiliary data:
            tracks_aux(kk).sleep_time = 0;
            
            % Removing chosen peak:
            pI = find(freqCand(bI)==peaks_freq);
            peaks_freq(pI) = [];
            peaks_amp(pI) = [];
            peaks_time(pI) = [];
            peaks_phase(pI) = [];

        else
        % Track continuation not found:
            if(tracks_aux(kk).sleep_time+1>=max_sleep_time),
            % This track is inactive and is removed from the active tracks vector.
                remove_vec(end+1) = kk;
            end

            tracks(kk).time(end+1) = tracks(kk).time(end)+ hop;
            % Storing values. The parameters assigned here are later on
            % interpolated using the 'interpTrack' function.
            tracks(kk).freq(end+1) = tracks(kk).freq(end);
            tracks(kk).amp(end+1) = -1;
            tracks(kk).phase(end+1) = tracks(kk).phase(end);

            % Storing auxiliary data:
            tracks_aux(kk).sleep_time = tracks_aux(kk).sleep_time+1;
        end

    end
    
    % Finding peaks that were not assigned to any track:
    for jj = 1:length(peaks_amp),

        % Creating new tracks to accommodate these peaks.
        tracks(end+1).time = peaks_time(jj);
        tracks(end).freq = peaks_freq(jj);
        tracks(end).amp = peaks_amp(jj);
        tracks(end).phase = peaks_phase(jj);

        tracks_aux(end+1).sleep_time = 0;

        active_vec(end+1) = length(tracks);
        pred_freq(end+1) = peaks_freq(jj);
        pred_amp(end+1) = peaks_amp(jj);

    end

	% Removing tracks that became inactive in frame ff:
    for ii = 1:length(remove_vec),
        
        jj = remove_vec(ii);
        kk = find(active_vec==jj);

        % Removing the track from the active tracks vector.
        active_vec(kk) = [];
        pred_freq(kk) = [];
        pred_amp(kk) = [];
        
        % Removing the dummy points inserted on the track.
        tracks(jj).time(end-max_sleep_time+1:end) = [];
        tracks(jj).freq(end-max_sleep_time+1:end) = [];
        tracks(jj).amp(end-max_sleep_time+1:end) = [];
        tracks(jj).phase(end-max_sleep_time+1:end) = [];
        
        % Re-initializing number of frames the track has been inactive:
        tracks_aux(jj).sleep_time = 0;
    end

end

% Removing dummy points inserted at the end of the tracks:
for ii=1:length(tracks)
    
        sleep_time = tracks_aux(ii).sleep_time;
        
        if(sleep_time)
            tracks(ii).time(end-sleep_time+1:end) = [];
            tracks(ii).freq(end-sleep_time+1:end) = [];
            tracks(ii).amp(end-sleep_time+1:end) = [];
            tracks(ii).phase(end-sleep_time+1:end) = [];
            tracks_aux(ii).sleep_time = 0;
        end
end

% Removing tracks whose duration is smaller than min_track_length:
rem_ind = [];
for ii=1:length(tracks),
    if((tracks(ii).time(end)-tracks(ii).time(1))<min_track_length),
        rem_ind(end+1) = ii;
    end
end
tracks(rem_ind) = [];
tracks_aux(rem_ind) = [];

function bI = dec_fun(tFreq,cFreq,tAmp,cAmp,kappa)
% Decision function: finds the peak that is the "best" continuation for the track given the candidate peaks.
%
% bI = dec_fun(tFreq,cFreq,tAmp,cAmp,kappa)
%
% tFreq - frequency of the track that is looking for its continuation
% cFreq - frequency of the peaks that are candidates for continuing the track
% tAmp - amplitude of the track that is looking for its continuation
% cAmp - amplitude of the peaks that are candidates for continuing the track
% kappa - weight that controls the emphasis between amplitude and frequency distances when choosing a continuation for a track. 0 <= kappa <= 1.
% bl - index of the chosen continuation for the track

% Calculating relative frequency and amplitude differences:
freqDiff = abs((tFreq-cFreq)./tFreq);
ampDiff = abs((tAmp-cAmp)./tAmp);

% Weighting the differences by kappa. 
met = (1-kappa)*freqDiff+kappa*ampDiff;

% Finding the minimum:
[y,bI] = min(met);
bI = bI(1);

