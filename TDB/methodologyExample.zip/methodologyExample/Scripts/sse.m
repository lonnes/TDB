function [nF] = sse(S,f_len)
% Noise floor estimation function
%
% nF = sse(S,f_len)
%
% where:
%
% S - spectrogram matrix
% f_len - length of the smoothing filter
% nF - estimated noise floor for each frame

% Leonardo Nunes  - lonnes@lps.ufrj.br


% Extending the spectrogram:
s_len = size(S,1);
e_points = f_len; % Setting number of extension points as the moving-average filter length.
ini_s = flipud(S(1:e_points,:));
end_s = flipud(S(s_len-(0:(e_points-1)),:));
eS = [ini_s;S;end_s];     % extended spectrogram to avoid boundary problems

% First three-tap moving-average filter:
S = filter([1 1 1]/3,1,eS);

% Reciprocal spectrogram:
S = S.^-1;

% Calculating noise floor:
h=ones(f_len,1)./f_len; % moving average filter
S_o = filter(h,1,S);

% Compensating for filter delay:
fdelay=round(1+(f_len-1)/2);
S_o = S_o(e_points+fdelay+(1:s_len),:);

% Obtaining noise floor estimate:
nF = S_o.^-1;