function trInt = interpTrack(tr,p)
% Missing Data Interpolation Algorithm for Partial Tracks
%
% trInt = interpTrack(tr,p) 
%
% where:
%
% tr - partial tracks that have data that need to be interpolated
% p - order of the autoregressive model used in the interpolation procedure  
% trInt - tracks after interpolation of missing data

% Leonardo Nunes - lonnes@lps.ufrj.br

F = 4; % maximum length of gaps in tracks.
tol = 1e-5; % error tolerance for AR-reconstruction.

trInt = tr; % Initialzing output tracks.

for ii=1:length(tr)
    
    % Finding the missing samples that can be interpolated 
    % by the AR-Reconstruction method (i.e., those that are not at the first or last p 
    % samples of the track). trAux contain the data in tr(ii) that can be interpolated by the 
    % AR-Reconstruction method.
    trAux = remMissingData(tr(ii),p);
    
    % Finding indices of the original track that remained in trAux
    indBeg = find(trAux.time(1)==tr(ii).time); % first index
    indEnd = find(trAux.time(end)==tr(ii).time); % last index
    
    % Extracting the amplitude and frequency trajectories that are going to be interpolated using the
    % AR-Reconstruction algorithm. The missing data in the phase trajectory is going to be linearly
    %  interpolated.
    a = trAux.amp;
    f = trAux.freq;
    phase = unwrap(trAux.phase);
     
    % Finding position of data that needs to be interpolated:
    ind = find(a==-1);

    if(~isempty(ind)) % Only proceeds if there is missing data in trAux.
    
        % Setting unknown data to zero:
		a(ind) = 0;
		f(ind) = 0;
	
		a = a(:);
		f = f(:);
		phase = phase(:);

        % Reconstructing amplitude and freq. using AR reconstruction algorithm:
        a_int = ar_reconstruction(tol,p,F,ind,a,[]);
        f_int = ar_reconstruction(tol,p,F,ind,f,[]);
        
        % Reconstructing phase information using linear interpolation:
        phase_aux = phase; % auxliary phase information
        phase_aux(ind) = []; % deleting unknown phase values (this is needed because of the syntax of the interpolation function)
        pos = 1:length(phase); % index of phase data
        posInt = pos;
        posInt(ind) = []; % deleting the positions that need to be interpolated
        phase_int = interp1(posInt,phase_aux,pos,'linear'); % call to linear interpolation function.

        % Assigning interpolated values back to the track structure:
        trInt(ii).amp(indBeg:indEnd) = a_int;
        trInt(ii).freq(indBeg:indEnd) = f_int;
        trInt(ii).phase(indBeg:indEnd) = phase_int;
    end
    
    % Interpolation of data at the beginning and end of the track (i.e. that were not already interpolated):
    
    % Finding the missing data in the beginning of the track:
    ind = find(trInt(ii).amp==-1);
    pos = 1:length(trInt(ii).amp);
    posInt = pos;
    
    % Extracting trajectories with missing data at its beginning and end:
    amp_aux = trInt(ii).amp;
    freq_aux = trInt(ii).freq;
    phase_aux = unwrap(trInt(ii).phase);
    
    % Removing data that is going to be interpolated (this is needed because of the syntax of the interpolation function):
    amp_aux(ind) = [];
    freq_aux(ind) = [];
    phase_aux(ind) = [];
    posInt(ind) = []; % deleting the positions that need to be interpolated
    
    % Interpolating the data:
    trInt(ii).phase = interp1(posInt,phase_aux,pos,'linear'); % call to linear interpolation function.
    trInt(ii).freq = interp1(posInt,freq_aux,pos,'spline'); % call to spline interpolation function.
    trInt(ii).amp = interp1(posInt,amp_aux,pos,'spline'); % call to spline interpolation function.

end


function [x,a]=ar_reconstruction(tol,p,F,falhas,x,a)
% This function implements the AR-based signal reconstruction
% tol: is an error tolerance used for terminating the iterations
% p: AR model order
% F: maximum number of consecutive missing samples
% falhas: indices of samples in x that are missing
% x: input signal marred with missing samples
% a: not used

if ~isempty(falhas),  % checks whether there are missing samples

    
    MaxIt = 1000; % maximum number of iterations!
    N=length(x);
    pmais1=p+1; 
    Nmenosp=N-p;
    maxNpF_mf=Nmenosp; 

    anta=zeros(p,1);   % previous coefficients of the AR model
    n=0;			   % iteration

    a=arburg(x(1:maxNpF_mf),p);  % current AR model estimation
    a(1)=[];
    a=a(:);
    a=-a;
    it=0; % iteration counter!
    % Performs signal reconstruction while the "differences" between the current and previous AR models are above tol  
    while ((norm(a-anta)/norm(a))>tol && it<=MaxIt)
       n=n+1;
       A=sparse(1:Nmenosp,pmais1:N,ones(1,Nmenosp),Nmenosp,N);
       for ii=1:p
          A=A+sparse(1:Nmenosp,(pmais1-ii):(N-ii),-a(ii)*ones(1,Nmenosp),Nmenosp,N);
       end
       falhasaux=[1:maxNpF_mf];
       
       falhasaux(falhas)=[];   

       Ad=A(1:maxNpF_mf-p,falhas);
       Ac=A(1:maxNpF_mf-p,falhasaux);
       clear A;  			   
       xc=x(falhasaux);
       clear falhasaux;
       Adt=Ad';  
       x(falhas)=-(Adt*Ad)\(Adt*(Ac*xc));    % LS AR interpolation
       clear Ad; 
       clear Ac; 
       anta=a;		% current AR model attributed to previous AR model vetor
       a=arburg(x(1:maxNpF_mf),p);   % estimates new (current) AR model from x with already reconstructed signal.
       a(1)=[];
       a=a(:);a=-a;
       it = it+1;
    end
end 

function trAux = remMissingData(trAux,p)
% This recursive function searches for portions at the beginning and end of
% the track that are missing and cannot be interpolated by the AR-Reconstruction method.
% It returns a portion of the track that can be interpolated with
% the AR-reconstruction method.

% Finding missing data:
ind = find(trAux.amp==-1);
L = length(trAux.amp);

% indices of missing data at the first p samples:
begInd = ind(ind<=p);

% indices of missing data at the last p samples:
endInd = ind(ind>L-p);

% Data to remove at the beginning and end of the track:
remBeg = 1:max(begInd);
remEnd = min(endInd):L;

% Removing missing data...
trAux.amp([remBeg remEnd]) = [];
trAux.freq([remBeg remEnd]) = [];
trAux.phase([remBeg remEnd]) = [];
trAux.time([remBeg remEnd]) = [];

if(~isempty([remBeg remEnd])) 
    % Data has been removed.
    
    % Recursive call to this function, new missing data might be in the
    % new beginning and end of the track:
    trAux = remMissingData(trAux,p);

end
