function [fHat,SHat] = QIFFT(S,peak_ind,f,K,Fs)
% Quadratic interpolation of spectral peaks
%
% [fHat Shat] = QIFFT(S,peak_ind,f,K,Fs)
%
% where:
%
% S - matrix containing the complex spectrogram of the signal
% peak_ind - indices of detected peaks
% f - frequency (in Hz) associated with each DFT bin
% K - DFT length
% Fs - sampling frequency
% fHat - a version of f containing the refined frequency (in Hz) in the positions corresponding to the spectral peaks
% SHat - a version of S  containing the refined magnitude and phase values in the positions corresponding to the spectral peaks

% Leonardo Nunes - lonnes@lps.ufrj.br

% Copying input to output variables:
fHat = f;
SHat = S;

for ii=1:length(peak_ind) % Loop over frames.

    f_aux = peak_ind{ii}; % Indices of peaks detected at frame ii.
    
    X = 20*log10(abs(S(:,ii))); % Magnitude of each peak.
    angleX = phase(S(:,ii)); % Phase of each peak.

    for jj = 1:length(f_aux) % Loop over peaks detected at frame ii.
        indMax = f_aux(jj);
    
        % Quadratic interpolation for frequency and amplitude:
        [p,y] = qint(X(indMax-1),X(indMax),X(indMax+1));

        % Linear interpolation for phase:
        aX = interp1([-1 0 1],[angleX(indMax-1),angleX(indMax),angleX(indMax+1)],p,'linear');

        % Assigning estimated values to the output:
        fHat(indMax,ii) = f(indMax,ii)+p*(Fs/K);
        SHat(indMax,ii) = 10^(y/20)*exp(j*aX); 
    end
end

function [p,y] = qint(ym1,y0,yp1)
% Quadratic interpolation:
%
% [p,y] = qint(ym1,y0,yp1)
%
% This function considers that the  points ym1, y0, and yp1 are
% on a parabola at abscissas -1, 0, and 1, respectively. It returns p, at abscissa position of the
% maximum of the parabola; and y, the value assumed by the maximum.

 p = (yp1 - ym1)/(2*(2*y0 - yp1 - ym1)); 
  
 y = y0 - 0.25*(ym1-yp1)*p;
 
