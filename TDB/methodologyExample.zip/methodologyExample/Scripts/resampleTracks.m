function trE = resampleTracks(tr,T)
% Resampling of the Parameters of the Partial Tracks
%
% trE = resampleTracks(tr,T)
%
% where:
%
% tr - partial tracks whose parameters are to be resampled
% T - new sampling period (in s)
% trE - partial tracks with resampled parameters

% Leonardo Nunes  - lonnes@lps.ufrj.br


% This function resamples the tracks to period T (in s). A linear
% interpolation algorithm is used.

for ii=1:length(tr)
    % Resampling one track at a time:
    
    % Loading track parameters:
    t = tr(ii).time;
    f = tr(ii).freq;
    phase = unwrap(tr(ii).phase);
    amp = tr(ii).amp;
    
   % Initializing auxliary vectors where the interpolated data will be stored:   
	ra = [];
    rf = [];
    rp = [];
    
    % Defining desired time instants:
    desiredT = 0:T:t(end);
    [val,ind] = min(abs(desiredT-t(1))); % Finding first time instant based on the track onset.
    desiredT = desiredT(ind+1:end);
    
    % Interpolating values:
    rf = interp1(t,f,desiredT,'linear');
    ra = interp1(t,amp,desiredT,'linear');
    rp = interp1(t,phase,desiredT,'linear');
    
    % Assigning new parameters to the track:
    tr(ii).phase = rp;
    tr(ii).freq = rf;
    tr(ii).amp = ra;
    tr(ii).time = desiredT;
    
end

trE = tr;