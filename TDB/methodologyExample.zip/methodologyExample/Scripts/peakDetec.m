function peak_ind = peakDetec(S,threshold,aNF,numPeaks)
% Peak detection function
%
% peak_ind = peakDetec(S,threshold,aNF,[numPeaks])
%
% S - complex spectrogram matrix
% threshold - local threshold
% aNF - global threshold
% numPeaks - [optional input argument] maximum number of selected peaks after detection
% peak_ind - indices of selected peaks in each frame (cell array)

% Leonardo Nunes - lonnes@lps.ufrj.br

% If numPeaks was not chosen by the user, it is set to zero (i.e. the number of selected peaks will
% not be limited).
if(nargin==3)
	numPeaks = 0;
end

% Obtaining the  spectrogram:
S = abs(S);

% Finding the indices of detected and selected peaks:
aux  = filter([1 -1],1,S);
aux = sign(aux);
aux = filter([1 -1],1,aux);

[r,c] = find(aux==-2);

for ii = 1:size(S,2),

	% Finding the indexes of the detected peaks at frame ii.
	ind = find(c==ii);
	aux_peaks = r(ind)-1;
	
	% Removing the index of the peak in the first bin that might have been detected:
	aux_peaks(aux_peaks==1) = [];
	
	% Storing detected peaks:
	peak_ind{ii} = aux_peaks; % Each element of this cell array contains the index of the detected peaks for a given frame.
	
	% Selecting peaks above both the local and global thresholds.
	peakAux = (S(peak_ind{ii},ii)<max(threshold(peak_ind{ii},ii),aNF(peak_ind{ii})));          
	peak_ind{ii}(peakAux) = []; 
	
	% Selecting the 'numPeaks' peaks with largest magnitude:
	if(numPeaks) % If numPeaks is equal to 0, this part of the code is skipped.
		[aux,ind] = sort(S(peak_ind{ii},ii),1,'descend');
		peak_aux = peak_ind{ii}(ind);
		N = length(peak_aux); 
		peak_ind{ii} = peak_aux(1:min(numPeaks,N));
	end
end