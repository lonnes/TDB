function [S,t,f] = spec(x,Fs,hop,window,dftLen)
% STFT algorithm
%
% [S,t,f] = spec(x,Fs,hop,window,dftLen)
%
% where:
%
% x - input signal
% Fs - sampling rate of the input signal
% hop - desired hop size (in s)
% window - samples of chosen window
% dftLen - number of bins in the DFT
%
% S - complex spectrogram matrix
% t - time (in s) of each frame index
% f - frequency (in Hz) of each DFT bin

% Leonardo Nunes  - lonnes@lps.ufrj.br

% This function calculates the complex spectrogram of a signal.
    x = x(:);

    % STFT parameters:
    hop = round(Fs*(hop));
    f_len = length(window);

    f_len_2 = (f_len-1)/2;

    nx = length(x); % Input signal length.
    n_hop = floor((nx)/hop)+1;  % Number of analysis frames.

    % Adjusting input signal length:
    x = [zeros(f_len_2,1);x;zeros((n_hop)*hop+f_len-nx,1)];

    colindex = (0:(n_hop-1))*(hop);
    rowindex = (1:f_len)';

    X = zeros(f_len,n_hop); % This matrix will contain one analysis frame at each column.

    % Filling the X matrix:
    X(:) = x(rowindex(:,ones(1,n_hop))+colindex(ones(f_len,1),:));

    % Windowing the signal:
    X = X.*window(:,ones(1,n_hop));

    % Zero-phase windowing:
    n_z = floor((dftLen-f_len)/2);
    X = [zeros(n_z,n_hop);X;zeros(n_z+1,n_hop)];
    X = fftshift(X,1);
    
    % Calculating the STFT and normalizing output:
    S = fft(X,dftLen)/sum(window);

    % Calculating the time and frequency vectors:
    aux = (hop/Fs);
    f = ((0:(dftLen/2))*(Fs/dftLen))';
    t = (0:n_hop-1)*(aux);
    t = t(ones(length(f),1),:);
    S = 2*S(1:length(f),:);
    f = f(:,ones(1,n_hop));