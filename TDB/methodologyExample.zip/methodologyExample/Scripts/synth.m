function x = synth(tr)
% Synthesis algorithm
%
% x = synth(tr)
%
% where:
%
% tr - partial track structure
% x - synhtesized signal at 44.1 kHz

% Leonardo Nunes  - lonnes@lps.ufrj.br


% This function synthesizes a signal given its sinusoidal tracks. The signal
% is always sampled at 44.1 kHz

%------------------------------------------------------------------------------
% Initializing variables:
max_len = 0; % Duration of the longest partial track.
x = []; % Output signal.

%--------------------------------------------------------------------------


fs = 44100; % Sampling frequency of the synthesized signal.
T = 1/fs; % Sampling period.

for kk=1:length(tr),% Loop over tracks
 
    % Reading track parameters:
    time_vec = tr(kk).time;
    amp_vec = tr(kk).amp;
    freq_vec = tr(kk).freq;
    phase_vec = tr(kk).phase;
    
    % Making sure the extracted parameters are row vectors:
    time_vec = time_vec(:);
    amp_vec = amp_vec(:);
    freq_vec = freq_vec(:);
    phase_vec = phase_vec(:);
    
    % Assigning null amplitude values in order to interpolate the amplitude
    % smoothly.
    if(time_vec(1)-2e-3 > 0)
        time_vec = [time_vec(1)-2e-3;time_vec;time_vec(end)+2e-3];
        amp_vec = [0;amp_vec;0];
        freq_vec = [freq_vec(1);freq_vec;freq_vec(end)];
        phase_vec = [phase_vec(1);phase_vec;phase_vec(end)];
    elseif(time_vec(1)==0)
        time_vec = [time_vec;time_vec(end)+2e-3];
        amp_vec = [amp_vec;0];
        freq_vec = [freq_vec;freq_vec(end)];
        phase_vec = [phase_vec;phase_vec(end)];
    end
        
    % initial time for track interpolation
    tr_first_sample = round(time_vec(1)*fs);
    
    % final time for track interpolation
    tr_final_sample = round(time_vec(end)*fs);

    if(max_len<tr_final_sample),
        max_len = tr_final_sample;
        x = [x;zeros(max_len-length(x)+1,1)];
    end

    n = time_vec(1):T:time_vec(end); % Desired time instants.
    f_n = time_vec; % Time instants when the parameters were estimated.

    % Interpolating the functions in time:
    inter_amp = interp1(f_n,amp_vec,n,'linear');
    inter_freq = interp1(f_n,freq_vec,n,'linear');
    inter_amp = max(inter_amp,1e-6);

    % Integrating frequency using trapezoids.
    aux = phase_vec(1); % Initial phase.
    f_m = zeros(1,length(inter_freq));
    f_m(1) = aux;

    for ii = 2:length(inter_freq),
        aux = aux + (inter_freq(ii)+inter_freq(ii-1))/(2*fs);
        f_m(ii) = aux;
    end

    x_aux = inter_amp.*cos((2*pi*(f_m))); % Synthesizing the track.

    % Adjusting the track length:
    x_aux = [zeros(tr_first_sample,1);x_aux';zeros(max_len-length(x_aux)-tr_first_sample+1,1)];

    % Summing signal synthesized for the current track with the signals
    % synthesized from previous tracks.
    if(kk~=1),
        x = x+x_aux;
    else
        x = x_aux;
    end
end